<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:89:"/Applications/MAMP/htdocs/cqpadmin/public/../application/index/view/index/viewticket.html";i:1539449823;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo $describe; ?>">
    <meta name="keywords" content="<?php echo $seo; ?>">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="/static/assets/images/favicon.png">
    <title>查看工单 - <?php echo $title; ?> - <?php echo $subtitle; ?></title>
    <!-- Bootstrap Core CSS -->
    <link href="/static/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/assets/css/toastr.min.css" rel="stylesheet">
    <link href="/static/assets/plugins/summernote/summernote-lite.css" rel="stylesheet">
    <!-- Footable CSS -->
    <link href="/static/assets/plugins/footable/css/footable.core.css" rel="stylesheet">
    <link href="/static/assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
    <!-- Custom CSS -->
    <link href="/static/assets/css/style.css" rel="stylesheet">
    <link href="/static/assets/plugins/jquery-rate/dist/themes/fontawesome-stars.css" rel="stylesheet">
    <!-- You can change the theme colors from here -->
    <link href="/static/assets/css/colors/blue.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body class="fix-header card-no-border logo-center">
<!-- ============================================================== -->
<!-- Preloader - style you can find in spinners.css -->
<!-- ============================================================== -->
<div class="preloader">
    <svg class="circular" viewBox="25 25 50 50">
        <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/>
    </svg>
</div>
<!-- ============================================================== -->
<!-- Main wrapper - style you can find in pages.scss -->
<!-- ============================================================== -->
<div id="main-wrapper">
    <!-- ============================================================== -->
    <!-- Topbar header - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <header class="topbar">
        <nav class="navbar top-navbar navbar-expand-md navbar-light">
            <!-- ============================================================== -->
            <!-- Logo -->
            <!-- ============================================================== -->
            <div class="navbar-header">
                <a class="navbar-brand" href="/index">
                    <!-- Logo icon -->
                    <b>
                        <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                        <!-- Dark Logo icon -->
                        <!--<img src="/static/assets/images/logo-icon.png" alt="homepage" class="dark-logo" />-->
                        <!-- Light Logo icon -->
                        <!--<img src="/static/assets/images/logo-light-icon.png" alt="homepage" class="light-logo" />-->
                        <i class="fa fa-modx light-logo"> <span>紫旭产品订阅平台</span></i>
                    </b>
                    <!--End Logo icon -->
                    <!-- Logo text -->
                </a>
            </div>
            <!-- ============================================================== -->
            <!-- End Logo -->
            <!-- ============================================================== -->
            <div class="navbar-collapse">
                <!-- ============================================================== -->
                <!-- toggle and nav items -->
                <!-- ============================================================== -->
                <ul class="navbar-nav mr-auto mt-md-0">
                    <!-- This is  -->
                    <li class="nav-item"><a class="nav-link nav-toggler hidden-md-up text-muted waves-effect waves-dark"
                                            href="javascript:void(0)"><i class="mdi mdi-menu"></i></a></li>
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                </ul>
                <!-- ============================================================== -->
                <!-- User profile and search -->
                <!-- ============================================================== -->
                <ul class="navbar-nav my-lg-0">
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Messages -->
                    <!-- ============================================================== -->
                    
                    <!-- ============================================================== -->
                    <!-- End Messages -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Profile -->
                    <!-- ============================================================== -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href=""
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img
                                src="<?php echo $avatar; ?>" alt="user" class="profile-pic"/></a>
                        <div class="dropdown-menu dropdown-menu-right scale-up">
                            <ul class="dropdown-user">
                                <li>
                                    <div class="dw-user-box">
                                        <div class="u-img"><img src="<?php echo $avatar; ?>" alt="user">
                                        </div>
                                        <div class="u-text"
                                             style="width: 146px;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                            <h4><?php echo $me['username']; ?></h4>
                                            <p class="text-muted"><?php echo $me['email']; ?></p>
                                            <div><h6><font color="<?php echo $group['groupcolor']; ?>"><?php echo $group['groupname']; ?></font></h6>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li role="separator" class="divider"></li>
                                <li><a href="/index/index/account"><i class="ti-user"></i> 个人中心</a></li>


                                <li role="separator" class="divider"></li>
                                <li><a href="/index/index/account"><i class="ti-settings"></i> 设置</a></li>
                                <li role="separator" class="divider"></li>
                                <li><a href="/index/user/logout"><i class="fa fa-power-off"></i> 退出登录</a></li>
                            </ul>
                        </div>
                    </li>
                    <!-- ============================================================== -->
                    <!-- Language -->
                    <!-- ============================================================== -->
                    <li class="nav-item dropdown">
                        <a class="nav-link waves-effect waves-dark" href="javascript:;"><i
                                class="flag-icon flag-icon-cn"></i></a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- ============================================================== -->
    <!-- End Topbar header -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <aside class="left-sidebar">
        <!-- Sidebar scroll-->
        <div class="scroll-sidebar">
            <!-- Sidebar navigation-->
            <nav class="sidebar-nav">
                <ul id="sidebarnav">
                    <li>
                        <a class="has-arrow" href="javascript:;" aria-expanded="false"><i
                                class="mdi mdi-gauge"></i><span
                                class="hide-menu">控制台</span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li><a href="/index/">主控制台</a></li>
                        </ul>
                    </li>
                    <li>
                        <a class="has-arrow" href="javascript:;" aria-expanded="false"><i
                                class="mdi mdi-widgets"></i><span
                                class="hide-menu">订阅管理</span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li><a href="/index/index/mySubscription">我的订阅</a></li>
                            <li><a href="/index/index/buyRecord">购买记录</a></li>
                        </ul>
                    </li>
                    <li>
                        <a class="has-arrow" href="javascript:;" aria-expanded="false"><i
                                class="mdi mdi-shopping"></i><span
                                class="hide-menu">商店</span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li><a href="/index/index/subscriptions">全部商品</a></li>
                            <li><a href="/index/index/charge">充值</a></li>

                        </ul>
                    </li>
                    <li class="active">
                        <a class="has-arrow " href="#" aria-expanded="false"><i class="mdi mdi-ticket-account"></i><span
                                class="hide-menu">工单</span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li><a href="/index/index/ticket">工单列表</a></li>
                            <li class="active"><a href="/index/index/newTicket">创建工单</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
            <!-- End Sidebar navigation -->
        </div>
        <!-- End Sidebar scroll-->
    </aside>
    <!-- ============================================================== -->
    <!-- End Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Page wrapper  -->
    <!-- ============================================================== -->
    <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 col-8 align-self-center">
                    <h3 class="text-themecolor m-b-0 m-t-0">查看工单</h3>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">工单</a></li>
                        <li class="breadcrumb-item active">查看工单</li>
                    </ol>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Start Page Content -->
            <!-- ============================================================== -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="alert alert-info">
                        <div class="row">
                            <span id="token" hidden data-token="<?php echo \think\Session::get('token'); ?>"></span>
                            <div class="col-lg-12"><h6>事件描述：<?php echo $t['tname']; ?></h6></div>
                            <div class="col-lg-3 col-md-12"><h6>工单编号：<span id="tid"><?php echo $t['tid']; ?></span></h6></div>
                            <div class="col-lg-3 col-md-12"><h6>创建时间：<?php echo $t['createtime']; ?></h6></div>
                            <div class="col-lg-3 col-md-12">
                                <h6><?php if($agent===false): ?>
                                    工单状态：
                                    <?php if($t['status']===0): ?>
                                    <span class="text-warning">等待分配</span>
                                    <?php elseif($t['status']===1): ?>
                                    <span class="text-info">已受理</span>
                                    <?php elseif($t['status']===2): ?>
                                    <span class="text-megna">处理中</span>
                                    <?php elseif($t['status']===3): ?>
                                    <span class="text-danger">待您处理</span>
                                    <?php elseif($t['status']===4): ?>
                                    <span class="text-megna">待您评价</span>
                                    <?php elseif($t['status']===5): ?>
                                    <span class="text-inverse">已结束</span>
                                    <?php endif; elseif($agent===true and $t['agent']===$me['uid']): ?>
                                    工单状态：
                                    <?php if($t['status']===0): ?>
                                    <span class="text-warning">可接单</span>
                                    <?php elseif($t['status']===1): ?>
                                    <span class="text-info">您已受理</span>
                                    <?php elseif($t['status']===2): ?>
                                    <span class="text-megna">待您处理</span>
                                    <?php elseif($t['status']===3): ?>
                                    <span class="text-danger">待客户处理</span>
                                    <?php elseif($t['status']===4): ?>
                                    <span class="text-primary">待客户评价</span>
                                    <?php elseif($t['status']===5): ?>
                                    <span class="text-inverse">已结束</span>
                                    <?php endif; else: ?>
                                    工单状态：
                                    <?php if($t['status']===0): ?>
                                    <span class="text-warning">可接单</span>
                                    <?php elseif($t['status']===1): ?>
                                    <span class="text-info">其他客服已受理</span>
                                    <?php elseif($t['status']===2): ?>
                                    <span class="text-megna">待客服处理</span>
                                    <?php elseif($t['status']===3): ?>
                                    <span class="text-danger">待客户处理</span>
                                    <?php elseif($t['status']===4): ?>
                                    <span class="text-primary">待客户评价</span>
                                    <?php elseif($t['status']===5): ?>
                                    <span class="text-inverse">已结束</span>
                                    <?php endif; endif; ?>
                                </h6>
                            </div>
                            <?php if($belong and $t['status']!=5 and $t['status']!=4): ?>
                            <div class="col-lg-3 col-md-12 text-right"><h6><a class="ticket_close" href="javascript:;">结束工单</a></h6></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="card card-outline-info">
                        <div class="card-header">
                            <h4 class="m-b-0 text-white">沟通记录</h4>
                        </div>
                        <!--<div class="card-body">-->
                        <!--<h4 class="card-title">沟通记录</h4>-->
                        <!--</div>-->
                        <div class="comment-widgets">
                            <!-- Comment Row -->
                            <?php if(is_array($reply) || $reply instanceof \think\Collection || $reply instanceof \think\Paginator): $i = 0; $__LIST__ = $reply;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$r): $mod = ($i % 2 );++$i;if($r['type']===0): ?>
                            <div class="d-flex flex-row comment-row">
                                <div class="p-2">
                                    <img class="round" src="<?php echo $clientavatar; ?>" alt="user" width="45">
                                </div>
                                <div class="comment-text w-100 p-2">
                                    <h5><font color="<?php echo $clientgroup['groupcolor']; ?>">[<?php echo $clientgroup['groupname']; ?>]
                                        <?php echo $client['username']; ?> :</font></h5>
                                    <?php echo $r['content']; ?>
                                    <div class="comment-footer">
                                        <small><?php echo $r['replytime']; ?></small>
                                    </div>
                                </div>
                            </div>
                            <?php elseif($r['type']===1): ?>
                            <div class="d-flex flex-row comment-row">
                                <div class="p-2">
                                    <span class="round round-primary">A</span>
                                </div>
                                <div class="comment-text w-100 p-2">
                                    <h5>客服 <?php echo $r['uid']; ?> 号 :</h5>
                                    <?php echo $r['content']; ?>
                                    <div class="comment-footer">
                                        <small><span class="label label-danger"><i class="fa fa-vcard"></i> 工作人员</span>
                                        </small>
                                        <small><?php echo $r['replytime']; ?></small>
                                    </div>
                                </div>
                            </div>
                            <?php endif; endforeach; endif; else: echo "" ;endif; ?>
                            <!-- Comment Row -->
                        </div>
                    </div>
                </div>
                <?php if($belong): ?>
                <!--属于自己，客服不能接自己的单-->
                <?php if($t['status']!=4 and $t['status']!=5): ?>
                <!--不是待评论或已结束-->
                <div id="client_newpost" class="col-lg-12">
                    <div class="card card-outline-info">
                        <div class="card-header">
                            <h4 class="m-b-0 text-white">追加回复</h4>
                        </div>
                        <div class="card-body">
                            <form id="newClientPostForm" class="form-horizontal floating-labels">
                                <div class="form-group">
                                    <textarea rows="4" class="summernote" name="content"></textarea>
                                    <span class="bar"></span>
                                    <small>请尽可能详细的描述您的事件，以更好更快的让工作人员帮您解决！</small>
                                </div>
                                <div class="form-actions text-right">
                                    <button type="button" class="reply btn btn-success"><i
                                            class="fa fa-check"></i> 提交
                                    </button>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
                <?php elseif($t['status']===4): ?>
                <!--这里要写评价区块代码-->
                <div id="client_rate" class="col-lg-12">
                    <div class="card card-outline-info">
                        <div class="card-header">
                            <h4 class="m-b-0 text-white">待您评分</h4>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <div class="stars stars-example-fontawesome">
                                    <div>请对本次服务评分：
                                        <select id="rate" name="rating">
                                            <option></option>
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <button id="ticket_rate" type="button" class="btn btn-success btn-rounded waves-effect">
                                提交
                            </button>
                        </div>
                    </div>
                </div>
                <?php endif; elseif($agent): ?>
                <!--不属于自己但是客服-->
                <?php if($t['status']===0): ?>
                <!--分配中，可以接单-->
                <div id="agent_accept" class="col-lg-12">
                    <div class="card card-outline-info">
                        <div class="card-header">
                            <h4 class="m-b-0 text-white">是否接受工单</h4>
                        </div>
                        <div class="card-body">
                            <button id="ticket_accept" type="button" class="btn btn-success btn-rounded waves-effect">
                                接受工单
                            </button>
                            <button id="ticket_cancel" type="button" class="btn btn-danger btn-rounded waves-effect">
                                取消并返回
                            </button>
                        </div>
                    </div>
                </div>
                <?php elseif($t['status']!=0 and $t['status']!=4 and $t['status']!=5 and $t['agent']==\think\Session::get('uid')): ?>
                <!--已被接单，并且是自己接的，并且工单不在评价或已结束流程-->
                <div id="agent_newpost" class="col-lg-12">
                    <div class="card card-outline-info">
                        <div class="card-header">
                            <h4 class="m-b-0 text-white">追加回复 - 客服模式</h4>
                        </div>
                        <div class="card-body">
                            <form id="newAgentPostForm" class="form-horizontal floating-labels">
                                <div class="form-group">
                                    <textarea rows="4" class="summernote" name="content"></textarea>
                                    <span class="bar"></span>
                                </div>
                                <div class="form-actions text-right">
                                    <button type="button" class="reply btn btn-success"><i
                                            class="fa fa-check"></i> 提交
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div id="agent_close" class="col-lg-12">
                    <div class="card card-outline-info">
                        <div class="card-header">
                            <h4 class="m-b-0 text-white">结束工单</h4>
                        </div>
                        <div class="card-body">
                            <button type="button" class="ticket_close btn btn-danger btn-rounded waves-effect">
                                结束工单
                            </button>
                        </div>
                        <!--结束工单后将进入待评价流程，评价完毕后自动结束工单-->
                    </div>
                </div>
                <!--不是自己接单，只能查看不能操作-->
                <?php endif; endif; ?>
            </div>
            <!-- ============================================================== -->
            <!-- End PAge Content -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Right sidebar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Container fluid  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer --><br/>
        <!-- ============================================================== -->
        <footer class="footer">
            © 2018 紫旭网络
            <br>
            <a href="javascript:;">备案号</a>
        </footer>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Page wrapper  -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="/static/assets/plugins/jquery/jquery.min.js"></script>
<script src="/static/assets/js/toastr.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="/static/assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="/static/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="/static/assets/js/jquery.slimscroll.js"></script>
<!--Wave Effects -->
<script src="/static/assets/js/waves.js"></script>
<!--Menu sidebar -->
<script src="/static/assets/js/sidebarmenu.js"></script>
<!--stickey kit -->
<script src="/static/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<!--Custom JavaScript -->
<script src="/static/assets/js/jquery.form.js"></script>
<script src="/static/assets/js/ticket.js"></script>
<script src="/static/assets/js/custom.min.js"></script>
<script src="/static/assets/plugins/jquery-rate/dist/jquery.barrating.min.js"></script>
<!-- Footable -->
<script src="/static/assets/plugins/footable/js/footable.all.min.js"></script>
<script src="/static/assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<!-- Editor Plugin JavaScript -->
<script src="/static/assets/plugins/summernote/summernote-lite.js"></script>
<script src="/static/assets/plugins/summernote/lang/summernote-zh-CN.js"></script>
<!--FooTable init-->
<script src="/static/assets/js/footable-init.js"></script>
<!-- ============================================================== -->
<!-- Style switcher -->
<!-- ============================================================== -->
<!--<script src="/static/assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>-->
</body>

</html>
