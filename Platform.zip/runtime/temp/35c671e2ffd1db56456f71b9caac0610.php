<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:90:"/Applications/MAMP/htdocs/cqpadmin/public/../application/index/view/index/mysubscribe.html";i:1537262549;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>我的订阅 - <?php echo $title; ?> - <?php echo $subtitle; ?></title>
    <meta name="description" content="<?php echo $describe; ?>">
    <meta name="keywords" content="<?php echo $seo; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="icon" type="image/png" href="/static/index-assets/i/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="/static/index-assets/i/app-icon72x72@2x.png">
    <meta name="apple-mobile-web-app-title" content="Amaze UI"/>
    <script src="/static/index-assets/js/echarts.min.js"></script>
    <link rel="stylesheet" href="/static/index-assets/css/amazeui.min.css"/>
    <link rel="stylesheet" href="/static/index-assets/css/amazeui.datatables.min.css"/>
    <link rel="stylesheet" href="/static/index-assets/css/app.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet"/>
    <script src="/static/index-assets/js/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


</head>

<body data-type="widgets">
<script src="/static/index-assets/js/theme.js"></script>
<div class="am-g tpl-g">
    <!-- 头部 -->
    <header>
        <!-- logo -->
        <div class="am-fl tpl-header-logo">
            <a href="/index"><i class="am-icon-modx am-icon-md"> Hello ZSRA</i></a>
        </div>
        <!-- 右侧内容 -->
        <div class="tpl-header-fluid">
            <!-- 侧边切换 -->
            <div class="am-fl tpl-header-switch-button am-icon-list">
                    <span>

                </span>
            </div>
            <!-- 搜索 -->
            <!--<div class="am-fl tpl-header-search">-->
            <!--<form class="tpl-header-search-form" action="javascript:;">-->
            <!--<button class="tpl-header-search-btn am-icon-search"></button>-->
            <!--<input class="tpl-header-search-box" type="text" placeholder="搜索内容...">-->
            <!--</form>-->
            <!--</div>-->
            <!-- 其它功能-->
            <div class="am-fr tpl-header-navbar">
                <ul>
                    <!-- 欢迎语 -->
                    <li class="am-text-sm tpl-header-navbar-welcome">
                        <a href="javascript:;">欢迎您，<span><?php echo $me['username']; ?></span> </a>
                    </li>

                    <!-- 新邮件 -->
                    <!--<li class="am-dropdown tpl-dropdown" data-am-dropdown>-->
                    <!--<a href="javascript:;" class="am-dropdown-toggle tpl-dropdown-toggle" data-am-dropdown-toggle>-->
                    <!--<i class="am-icon-envelope"></i>-->
                    <!--<span class="am-badge am-badge-success am-round item-feed-badge">4</span>-->
                    <!--</a>-->
                    <!--&lt;!&ndash; 弹出列表 &ndash;&gt;-->
                    <!--<ul class="am-dropdown-content tpl-dropdown-content">-->
                    <!--<li class="tpl-dropdown-menu-messages">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-messages-item am-cf">-->
                    <!--<div class="menu-messages-ico">-->
                    <!--<img src="/static/index-assets/img/user04.png" alt="">-->
                    <!--</div>-->
                    <!--<div class="menu-messages-time">-->
                    <!--3小时前-->
                    <!--</div>-->
                    <!--<div class="menu-messages-content">-->
                    <!--<div class="menu-messages-content-title">-->
                    <!--<i class="am-icon-circle-o am-text-success"></i>-->
                    <!--<span>夕风色</span>-->
                    <!--</div>-->
                    <!--<div class="am-text-truncate"> Amaze UI 的诞生，依托于 GitHub 及其他技术社区上一些优秀的资源；Amaze UI 的成长，则离不开用户的支持。 </div>-->
                    <!--<div class="menu-messages-content-time">2016-09-21 下午 16:40</div>-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->

                    <!--<li class="tpl-dropdown-menu-messages">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-messages-item am-cf">-->
                    <!--<div class="menu-messages-ico">-->
                    <!--<img src="/static/index-assets/img/user02.png" alt="">-->
                    <!--</div>-->
                    <!--<div class="menu-messages-time">-->
                    <!--5天前-->
                    <!--</div>-->
                    <!--<div class="menu-messages-content">-->
                    <!--<div class="menu-messages-content-title">-->
                    <!--<i class="am-icon-circle-o am-text-warning"></i>-->
                    <!--<span>禁言小张</span>-->
                    <!--</div>-->
                    <!--<div class="am-text-truncate"> 为了能最准确的传达所描述的问题， 建议你在反馈时附上演示，方便我们理解。 </div>-->
                    <!--<div class="menu-messages-content-time">2016-09-16 上午 09:23</div>-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--<li class="tpl-dropdown-menu-messages">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-messages-item am-cf">-->
                    <!--<i class="am-icon-circle-o"></i> 进入列表…-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--</ul>-->
                    <!--</li>-->

                    <!-- 新提示 -->
                    <!--<li class="am-dropdown" data-am-dropdown>-->
                    <!--<a href="javascript:;" class="am-dropdown-toggle" data-am-dropdown-toggle>-->
                    <!--<i class="am-icon-bell"></i>-->
                    <!--<span class="am-badge am-badge-warning am-round item-feed-badge">5</span>-->
                    <!--</a>-->

                    <!--&lt;!&ndash; 弹出列表 &ndash;&gt;-->
                    <!--<ul class="am-dropdown-content tpl-dropdown-content">-->
                    <!--<li class="tpl-dropdown-menu-notifications">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-notifications-item am-cf">-->
                    <!--<div class="tpl-dropdown-menu-notifications-title">-->
                    <!--<i class="am-icon-line-chart"></i>-->
                    <!--<span> 有6笔新的销售订单</span>-->
                    <!--</div>-->
                    <!--<div class="tpl-dropdown-menu-notifications-time">-->
                    <!--12分钟前-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--<li class="tpl-dropdown-menu-notifications">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-notifications-item am-cf">-->
                    <!--<div class="tpl-dropdown-menu-notifications-title">-->
                    <!--<i class="am-icon-star"></i>-->
                    <!--<span> 有3个来自人事部的消息</span>-->
                    <!--</div>-->
                    <!--<div class="tpl-dropdown-menu-notifications-time">-->
                    <!--30分钟前-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--<li class="tpl-dropdown-menu-notifications">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-notifications-item am-cf">-->
                    <!--<div class="tpl-dropdown-menu-notifications-title">-->
                    <!--<i class="am-icon-folder-o"></i>-->
                    <!--<span> 上午开会记录存档</span>-->
                    <!--</div>-->
                    <!--<div class="tpl-dropdown-menu-notifications-time">-->
                    <!--1天前-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->


                    <!--<li class="tpl-dropdown-menu-notifications">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-notifications-item am-cf">-->
                    <!--<i class="am-icon-bell"></i> 进入列表…-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--</ul>-->
                    <!--</li>-->

                    <!-- 退出 -->
                    <li class="am-text-sm">
                        <a href="/index/user/logout">
                            <span class="am-icon-sign-out"></span> 退出
                        </a>
                    </li>
                </ul>
            </div>
        </div>

    </header>
    <!-- 风格切换 -->
    <div class="tpl-skiner">
        <div class="tpl-skiner-toggle am-icon-cog">
        </div>
        <div class="tpl-skiner-content">
            <div class="tpl-skiner-content-title">
                选择主题
            </div>
            <div class="tpl-skiner-content-bar">
                <span class="skiner-color skiner-white" data-color="theme-white"></span>
                <span class="skiner-color skiner-black" data-color="theme-black"></span>
            </div>
        </div>
    </div>
    <!-- 侧边导航栏 -->
    <div class="left-sidebar">
        <!-- 用户信息 -->
        <div class="tpl-sidebar-user-panel">
            <div class="tpl-user-panel-slide-toggleable">
                <div class="tpl-user-panel-profile-picture">
                    <img src="/static/index-assets/img/user04.png" alt="">
                </div>
                <span class="user-panel-logged-in-text">
              <i class="am-icon-circle-o am-text-success tpl-user-panel-status-icon"></i>
              <?php echo $me['username']; ?>#<?php echo $me['uid']; ?>
          </span>
                <a href="javascript:;" class="tpl-user-panel-action-link"> <span class="am-icon-pencil"></span> 账号设置</a>
            </div>
        </div>

        <!-- 菜单 -->
        <ul class="sidebar-nav">
            <li class="sidebar-nav-heading">控制台 <span class="sidebar-nav-heading-info"> Console</span></li>
            <li class="sidebar-nav-link">
                <a href="/index">
                    <i class="am-icon-home sidebar-nav-link-logo"></i> 首页
                </a>
            </li>
            <li class="sidebar-nav-link">
                <a href="javascript:;" class="sidebar-nav-sub-title active">
                    <i class="am-icon-cloud sidebar-nav-link-logo"></i> 订阅管理
                    <span class="am-icon-chevron-down am-fr am-margin-right-sm sidebar-nav-sub-ico sidebar-nav-sub-ico-rotate"></span>
                </a>
                <ul class="sidebar-nav sidebar-nav-sub" style="display: block;">
                    <li class="sidebar-nav-link">
                        <a href="/index/index/mySubscribe" class="sub-active">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 我的订阅
                        </a>
                    </li>

                    <li class="sidebar-nav-link">
                        <a href="/index/index/subscribe">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 订阅列表
                        </a>
                    </li>
                </ul>
            </li>
            <li class="sidebar-nav-link">
                <a href="javascript:;" class="sidebar-nav-sub-title">
                    <i class="am-icon-google-wallet sidebar-nav-link-logo"></i> 账户管理
                    <span class="am-icon-chevron-down am-fr am-margin-right-sm sidebar-nav-sub-ico"></span>
                </a>
                <ul class="sidebar-nav sidebar-nav-sub">
                    <li class="sidebar-nav-link">
                        <a href="/index/index/account">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 我的账户
                        </a>
                    </li>
                    <li class="sidebar-nav-link">
                        <a href="/index/index/editacc">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 资料编辑
                        </a>
                    </li>
                    <li class="sidebar-nav-link">
                        <a href="javascript:;">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 购买记录
                        </a>
                    </li>
                </ul>
            </li>
            <li class="sidebar-nav-link">
                <a href="/index/index/charge">
                    <i class="am-icon-usd sidebar-nav-link-logo"></i> 账户充值
                </a>
            </li>
            <li class="sidebar-nav-link">
                <a href="javascript:;" class="sidebar-nav-sub-title">
                    <i class="am-icon-ticket sidebar-nav-link-logo"></i> 工单
                    <span class="am-icon-chevron-down am-fr am-margin-right-sm sidebar-nav-sub-ico"></span>
                </a>
                <ul class="sidebar-nav sidebar-nav-sub">
                    <li class="sidebar-nav-link">
                        <a href="javascript:;">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 我的工单
                        </a>
                    </li>
                    <li class="sidebar-nav-link">
                        <a href="javascript:;">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 提交工单
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>


    <!-- 内容区域 -->
    <div class="tpl-content-wrapper">
        <div class="container-fluid am-cf">
            <div class="row">
                <div class="am-u-sm-12 am-u-md-12 am-u-lg-9">
                    <div class="page-header-heading"><span class="am-icon-home page-header-heading-icon"></span> 我的订阅
                        <small>ZSRA</small>
                    </div>
                    <p class="page-header-description">在这里可以查看和管理您的订阅！</p>
                </div>
                <!--<div class="am-u-lg-3 tpl-index-settings-button">-->
                <!--<button type="button" class="page-header-button"><span class="am-icon-paint-brush"></span> 设置</button>-->
                <!--</div>-->
            </div>
        </div>
        <div class="row-content am-cf">
            <div class="row">
                <div class="am-u-sm-12 am-u-md-12 am-u-lg-12">
                    <div class="widget am-cf">
                        <div class="widget-head am-cf">
                            <div class="widget-title am-cf">我的订阅</div>
                        </div>
                        <div class="widget-body  am-fr">
                            <div class="am-u-sm-12">
                                <table width="100%" class="am-table am-table-compact am-table-striped tpl-table-black "
                                       id="example-r">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>产品名</th>
                                        <th>状态</th>
                                        <th>剩余天数</th>
                                        <th>到期时间</th>
                                        <th>操作</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(is_array($mysub) || $mysub instanceof \think\Collection || $mysub instanceof \think\Paginator): $i = 0; $__LIST__ = $mysub;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ms): $mod = ($i % 2 );++$i;?>
                                    <tr>
                                        <td>#<?php echo $ms['sid']; ?></td>
                                        <td><?php echo $ms['sname']; ?></td>
                                        <td><?php if((strtotime($ms['expiretime'])-time()>0) and
                                            ($ms['status']==='正常')): ?><i class="am-icon-play-circle-o"> 使用中</i><?php elseif((strtotime($ms['expiretime'])-time()<=0)): ?><font
                                                    color="red"><i class="am-icon-stop-circle-o"> 已过期</i></font><?php elseif(($ms['status']==='停用')): ?><font color="orange"><i class="am-icon-pause-circle-o"> 被停用</i></font><?php endif; ?>
                                        </td>
                                        <td><?php if((strtotime($ms['expiretime'])-time()>0)): ?><?php echo number_format(strtotime($ms['expiretime'])/86400-time()/86400,2); ?>天<?php else: ?>0天<?php endif; ?>
                                        </td>
                                        <td><?php echo $ms['expiretime']; ?></td>
                                        <td>
                                            <div class="tpl-table-black-operation">
                                                <?php if(($ms['groupnum']===0) and
                                                (strtotime($ms['expiretime'])-time()>0) and
                                                ($ms['status']!='停用')): ?>
                                                <a href="javascript:;" class="btn_detail"
                                                   data-am-popover="{content: '查看详情', trigger: 'hover', theme:'sm'}">
                                                    <i class="am-icon-eye"></i>
                                                </a>
                                                <?php endif; if((strtotime($ms['expiretime'])-time()>0) and
                                                ($ms['status']!='停用')): ?>
                                                <a href="/index/index/order?sid=<?php echo $ms['sid']; ?>&type=renew&renewid=<?php echo $ms['id']; ?>" class="btn_renew" data-am-popover="{content: '续期', trigger: 'hover', theme:'sm success'}">
                                                    <i class="am-icon-first-order"></i>
                                                </a>
                                                <?php endif; if((strtotime($ms['expiretime'])-time()<=0) and
                                                ($ms['status']!='停用')): ?>
                                                <a href="/index/index/order?sid=<?php echo $ms['sid']; ?>" class="btn_renew"
                                                   data-am-popover="{content: '重新购买这个产品', trigger: 'hover', theme:'sm primary'}">
                                                    <i class="am-icon-first-order"></i>
                                                </a>
                                                <?php endif; if(($ms['groupnum']===0) and
                                                (strtotime($ms['expiretime'])-time()>0) and
                                                ($ms['status']!='停用')): ?>
                                                <a href="javascript:;" class="btn_bindgroup" data-am-popover="{content: '绑定QQ群号码', trigger: 'hover', theme:'sm primary'}">
                                                    <i class="am-icon-group"></i>
                                                </a>
                                                <?php endif; if((strtotime($ms['expiretime'])-time()<=0) or
                                                ($ms['status']==='停用')): ?>
                                                <a href="javascript:;" class="btn_remove tpl-table-black-operation-del"
                                                   data-am-popover="{content: '移除这个订阅', trigger: 'hover', theme:'sm danger'}">
                                                    <i class="am-icon-trash"></i>
                                                </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                    <!-- more data -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script src="/static/index-assets/js/amazeui.min.js"></script>
<script src="/static/index-assets/js/amazeui.datatables.min.js"></script>
<script src="/static/index-assets/js/dataTables.responsive.min.js"></script>
<script src="/static/index-assets/js/app.js"></script>

</body>

</html>