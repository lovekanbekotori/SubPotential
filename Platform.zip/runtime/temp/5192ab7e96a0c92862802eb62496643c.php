<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:67:"/Applications/MAMP/htdocs/tp5/application/index/view/blog/blog.html";i:1533321958;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>blog</title>
</head>
<body>
<span>姓名：</span>
<input id="name" type="text" />
<input id="submit" type="submit" formtarget="Blog.php" value="提交" />
<script>
</script>
</body>
</html>