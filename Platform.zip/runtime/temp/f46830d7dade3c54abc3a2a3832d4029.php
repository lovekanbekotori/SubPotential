<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"/Applications/MAMP/htdocs/cqpadmin/public/../application/index/view/index/index.html";i:1537455788;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $title; ?> - <?php echo $subtitle; ?></title>
    <meta name="description" content="<?php echo $describe; ?>">
    <meta name="keywords" content="<?php echo $seo; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="icon" type="image/png" href="/static/index-assets/i/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="/static/index-assets/i/app-icon72x72@2x.png">
    <meta name="apple-mobile-web-app-title" content="Amaze UI"/>
    <script src="/static/index-assets/js/echarts.min.js"></script>
    <link rel="stylesheet" href="/static/index-assets/css/amazeui.min.css"/>
    <link rel="stylesheet" href="/static/index-assets/css/amazeui.datatables.min.css"/>
    <link rel="stylesheet" href="/static/index-assets/css/app.css">
    <link rel="stylesheet" href="/static/index-assets/css/toastr.min.css">
    <script src="/static/index-assets/js/jquery.min.js"></script>
    <script src="/static/index-assets/js/jquery.form.js"></script>
    <script src="/static/index-assets/js/toastr.min.js"></script>

</head>

<body data-type="index">
<script src="/static/index-assets/js/theme.js"></script>
<div class="am-g tpl-g">
    <!-- 头部 -->
    <header>
        <!-- logo -->
        <div class="am-fl tpl-header-logo">
            <a href="/index"><i class="am-icon-modx am-icon-md"> Hello ZSRA</i></a>
        </div>
        <!-- 右侧内容 -->
        <div class="tpl-header-fluid">
            <!-- 侧边切换 -->
            <div class="am-fl tpl-header-switch-button am-icon-list">
                    <span>

                </span>
            </div>
            <!-- 搜索 -->
            <!--<div class="am-fl tpl-header-search">-->
            <!--<form class="tpl-header-search-form" action="javascript:;">-->
            <!--<button class="tpl-header-search-btn am-icon-search"></button>-->
            <!--<input class="tpl-header-search-box" type="text" placeholder="搜索内容...">-->
            <!--</form>-->
            <!--</div>-->
            <!-- 其它功能-->
            <div class="am-fr tpl-header-navbar">
                <ul>
                    <!-- 欢迎语 -->
                    <li class="am-text-sm tpl-header-navbar-welcome">
                        <a href="javascript:;">欢迎您，<span><?php echo $me['username']; ?></span> </a>
                    </li>

                    <!-- 新邮件 -->
                    <!--<li class="am-dropdown tpl-dropdown" data-am-dropdown>-->
                    <!--<a href="javascript:;" class="am-dropdown-toggle tpl-dropdown-toggle" data-am-dropdown-toggle>-->
                    <!--<i class="am-icon-envelope"></i>-->
                    <!--<span class="am-badge am-badge-success am-round item-feed-badge">4</span>-->
                    <!--</a>-->
                    <!--&lt;!&ndash; 弹出列表 &ndash;&gt;-->
                    <!--<ul class="am-dropdown-content tpl-dropdown-content">-->
                    <!--<li class="tpl-dropdown-menu-messages">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-messages-item am-cf">-->
                    <!--<div class="menu-messages-ico">-->
                    <!--<img src="/static/index-assets/img/user04.png" alt="">-->
                    <!--</div>-->
                    <!--<div class="menu-messages-time">-->
                    <!--3小时前-->
                    <!--</div>-->
                    <!--<div class="menu-messages-content">-->
                    <!--<div class="menu-messages-content-title">-->
                    <!--<i class="am-icon-circle-o am-text-success"></i>-->
                    <!--<span>夕风色</span>-->
                    <!--</div>-->
                    <!--<div class="am-text-truncate"> Amaze UI 的诞生，依托于 GitHub 及其他技术社区上一些优秀的资源；Amaze UI-->
                    <!--的成长，则离不开用户的支持。-->
                    <!--</div>-->
                    <!--<div class="menu-messages-content-time">2016-09-21 下午 16:40</div>-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->

                    <!--<li class="tpl-dropdown-menu-messages">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-messages-item am-cf">-->
                    <!--<div class="menu-messages-ico">-->
                    <!--<img src="/static/index-assets/img/user02.png" alt="">-->
                    <!--</div>-->
                    <!--<div class="menu-messages-time">-->
                    <!--5天前-->
                    <!--</div>-->
                    <!--<div class="menu-messages-content">-->
                    <!--<div class="menu-messages-content-title">-->
                    <!--<i class="am-icon-circle-o am-text-warning"></i>-->
                    <!--<span>禁言小张</span>-->
                    <!--</div>-->
                    <!--<div class="am-text-truncate"> 为了能最准确的传达所描述的问题， 建议你在反馈时附上演示，方便我们理解。</div>-->
                    <!--<div class="menu-messages-content-time">2016-09-16 上午 09:23</div>-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--<li class="tpl-dropdown-menu-messages">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-messages-item am-cf">-->
                    <!--<i class="am-icon-circle-o"></i> 进入列表…-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--</ul>-->
                    <!--</li>-->

                    <!-- 新提示 -->
                    <!--<li class="am-dropdown" data-am-dropdown>-->
                    <!--<a href="javascript:;" class="am-dropdown-toggle" data-am-dropdown-toggle>-->
                    <!--<i class="am-icon-bell"></i>-->
                    <!--<span class="am-badge am-badge-warning am-round item-feed-badge">5</span>-->
                    <!--</a>-->

                    <!--&lt;!&ndash; 弹出列表 &ndash;&gt;-->
                    <!--<ul class="am-dropdown-content tpl-dropdown-content">-->
                    <!--<li class="tpl-dropdown-menu-notifications">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-notifications-item am-cf">-->
                    <!--<div class="tpl-dropdown-menu-notifications-title">-->
                    <!--<i class="am-icon-line-chart"></i>-->
                    <!--<span> 有6笔新的销售订单</span>-->
                    <!--</div>-->
                    <!--<div class="tpl-dropdown-menu-notifications-time">-->
                    <!--12分钟前-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--<li class="tpl-dropdown-menu-notifications">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-notifications-item am-cf">-->
                    <!--<div class="tpl-dropdown-menu-notifications-title">-->
                    <!--<i class="am-icon-star"></i>-->
                    <!--<span> 有3个来自人事部的消息</span>-->
                    <!--</div>-->
                    <!--<div class="tpl-dropdown-menu-notifications-time">-->
                    <!--30分钟前-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--<li class="tpl-dropdown-menu-notifications">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-notifications-item am-cf">-->
                    <!--<div class="tpl-dropdown-menu-notifications-title">-->
                    <!--<i class="am-icon-folder-o"></i>-->
                    <!--<span> 上午开会记录存档</span>-->
                    <!--</div>-->
                    <!--<div class="tpl-dropdown-menu-notifications-time">-->
                    <!--1天前-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->


                    <!--<li class="tpl-dropdown-menu-notifications">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-notifications-item am-cf">-->
                    <!--<i class="am-icon-bell"></i> 进入列表…-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--</ul>-->
                    <!--</li>-->

                    <!-- 退出 -->
                    <li class="am-text-sm">
                        <a href="/index/user/logout">
                            <span class="am-icon-sign-out"></span> 退出
                        </a>
                    </li>
                </ul>
            </div>
        </div>

    </header>
    <!-- 风格切换 -->
    <div class="tpl-skiner">
        <div class="tpl-skiner-toggle am-icon-cog">
        </div>
        <div class="tpl-skiner-content">
            <div class="tpl-skiner-content-title">
                选择主题
            </div>
            <div class="tpl-skiner-content-bar">
                <span class="skiner-color skiner-white" data-color="theme-white"></span>
                <span class="skiner-color skiner-black" data-color="theme-black"></span>
            </div>
        </div>
    </div>
    <!-- 侧边导航栏 -->
    <div class="left-sidebar">
        <!-- 用户信息 -->
        <div class="tpl-sidebar-user-panel">
            <div class="tpl-user-panel-slide-toggleable">
                <div class="tpl-user-panel-profile-picture">
                    <img src="/static/index-assets/img/user04.png" alt="">
                </div>
                <span class="user-panel-logged-in-text">
              <i class="am-icon-circle-o am-text-success tpl-user-panel-status-icon"></i>
              <?php echo $me['username']; ?>#<?php echo $me['uid']; ?>
          </span>
                <a href="javascript:;" class="tpl-user-panel-action-link"> <span class="am-icon-pencil"></span> 账号设置</a>
            </div>
        </div>

        <!-- 菜单 -->
        <ul class="sidebar-nav">
            <li class="sidebar-nav-heading">控制台 <span class="sidebar-nav-heading-info"> Console</span></li>
            <li class="sidebar-nav-link">
                <a href="/index" class="active">
                    <i class="am-icon-home sidebar-nav-link-logo"></i> 首页
                </a>
            </li>
            <li class="sidebar-nav-link">
                <a href="javascript:;" class="sidebar-nav-sub-title">
                    <i class="am-icon-cloud sidebar-nav-link-logo"></i> 订阅管理
                    <span class="am-icon-chevron-down am-fr am-margin-right-sm sidebar-nav-sub-ico"></span>
                </a>
                <ul class="sidebar-nav sidebar-nav-sub">
                    <li class="sidebar-nav-link">
                        <a href="/index/index/mySubscribe">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 我的订阅
                        </a>
                    </li>

                    <li class="sidebar-nav-link">
                        <a href="/index/index/subscribe">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 订阅列表
                        </a>
                    </li>
                </ul>
            </li>
            <li class="sidebar-nav-link">
                <a href="javascript:;" class="sidebar-nav-sub-title">
                    <i class="am-icon-google-wallet sidebar-nav-link-logo"></i> 账户管理
                    <span class="am-icon-chevron-down am-fr am-margin-right-sm sidebar-nav-sub-ico"></span>
                </a>
                <ul class="sidebar-nav sidebar-nav-sub">
                    <li class="sidebar-nav-link">
                        <a href="/index/index/account">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 我的账户
                        </a>
                    </li>
                    <li class="sidebar-nav-link">
                        <a href="/index/index/editacc">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 资料编辑
                        </a>
                    </li>
                    <li class="sidebar-nav-link">
                        <a href="javascript:;">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 购买记录
                        </a>
                    </li>
                </ul>
            </li>
            <li class="sidebar-nav-link">
                <a href="/index/index/charge">
                    <i class="am-icon-usd sidebar-nav-link-logo"></i> 账户充值
                </a>
            </li>
            <li class="sidebar-nav-link">
                <a href="javascript:;" class="sidebar-nav-sub-title">
                    <i class="am-icon-ticket sidebar-nav-link-logo"></i> 工单
                    <span class="am-icon-chevron-down am-fr am-margin-right-sm sidebar-nav-sub-ico"></span>
                </a>
                <ul class="sidebar-nav sidebar-nav-sub">
                    <li class="sidebar-nav-link">
                        <a href="javascript:;">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 我的工单
                        </a>
                    </li>
                    <li class="sidebar-nav-link">
                        <a href="javascript:;">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 提交工单
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>


    <!-- 内容区域 -->
    <div class="tpl-content-wrapper">

        <div class="container-fluid am-cf">
            <div class="row">
                <div class="am-u-sm-12 am-u-md-12 am-u-lg-9">
                    <div class="page-header-heading"><span class="am-icon-home page-header-heading-icon"></span> 仪表盘
                        <small>ZSRA</small>
                    </div>
                    <p class="page-header-description">即刻开始，选择你喜欢的QQ机器人项目进行订阅，体验全自动的群管理！</p>
                </div>
                <!--<div class="am-u-lg-3 tpl-index-settings-button">-->
                <!--<button type="button" class="page-header-button"><span class="am-icon-paint-brush"></span> 设置</button>-->
                <!--</div>-->
            </div>
        </div>

        <div class="row-content am-cf">
            <div class="row am-cf">
                <!--<div class="am-u-sm-12 am-u-md-12 am-u-lg-4">-->
                <!--<div class="widget am-cf">-->
                <!--<div class="widget-head am-cf">-->
                <!--<div class="widget-title am-fl">月度财务收支计划</div>-->
                <!--<div class="widget-function am-fr">-->
                <!--<a href="javascript:;" class="am-icon-cog"></a>-->
                <!--</div>-->
                <!--</div>-->
                <!--<div class="widget-body am-fr">-->
                <!--<div class="am-fl">-->
                <!--<div class="widget-fluctuation-period-text">-->
                <!--￥61746.45-->
                <!--<button class="widget-fluctuation-tpl-btn">-->
                <!--<i class="am-icon-calendar"></i>-->
                <!--更多月份-->
                <!--</button>-->
                <!--</div>-->
                <!--</div>-->
                <!--<div class="am-fr am-cf">-->
                <!--<div class="widget-fluctuation-description-amount text-success" am-cf>-->
                <!--+￥30420.56-->

                <!--</div>-->
                <!--<div class="widget-fluctuation-description-text am-text-right">-->
                <!--8月份收入-->
                <!--</div>-->
                <!--</div>-->
                <!--</div>-->
                <!--</div>-->

                <!--</div>-->
                <div class="am-u-sm-12 am-u-md-6 am-u-lg-4">
                    <div class="widget widget-purple am-cf">
                        <div class="widget-statistic-header">
                            钱包余额
                        </div>
                        <div class="widget-statistic-body">
                            <div class="widget-statistic-value">
                                ￥<?php echo $me['cash']; ?>
                            </div>
                            <div class="widget-statistic-description">
                                <button id="chongzhi" class="am-btn am-btn-xs am-round am-btn-success">充值</button>
                                <button id="mingxi" class="am-btn am-btn-xs am-round am-btn-primary">明细</button>
                                <button id="tixian" class="am-btn am-btn-xs am-round am-btn-secondary">提现</button>
                            </div>
                            <span class="widget-statistic-icon am-icon-credit-card"></span>
                        </div>
                    </div>
                </div>
                <div class="am-u-sm-12 am-u-md-6 am-u-lg-4">
                    <div class="widget widget-primary am-cf">
                        <div class="widget-statistic-header">
                            有效订阅总数
                        </div>
                        <div class="widget-statistic-body">
                            <div class="widget-statistic-value">
                                <?php echo $subcount; ?>个
                            </div>
                            <div class="widget-statistic-description">
                                其中有 <strong><?php echo $willexpire; ?></strong> 个即将到期
                            </div>
                            <span class="widget-statistic-icon am-icon-archive"></span>
                        </div>
                    </div>
                </div>
                <div class="am-u-sm-12 am-u-md-6 am-u-lg-4">
                    <div class="widget widget-green am-cf">
                        <div class="widget-statistic-header">
                            积分
                        </div>
                        <div class="widget-statistic-body">
                            <div class="widget-statistic-value">
                                <?php echo $me['credit']; ?>点
                            </div>
                            <div class="widget-statistic-description">
                                积分将在 <strong>2018年12月31日</strong> 过期
                            </div>
                            <span class="widget-statistic-icon am-icon-diamond"></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row am-cf">
                <div class="am-u-sm-12 am-u-md-12 am-u-lg-8">
                    <div class="widget am-cf">
                        <div class="widget-head am-cf">
                            <div class="widget-title am-fl">公告列表</div>
                            <!--<div class="widget-function am-fr">-->
                            <!--<a href="javascript:;" class="am-icon-cog"></a>-->
                            <!--</div>-->
                        </div>
                        <div class="widget-body  widget-body-lg am-fr">
                            <div class="am-scrollable-horizontal ">
                                <table width="100%" class="am-table am-table-compact am-text-nowrap tpl-table-black "
                                       id="example-r">
                                    <thead>
                                    <tr>
                                        <th>公告标题</th>
                                        <th>作者</th>
                                        <th>时间</th>
                                        <th>操作</th>
                                    </tr>
                                    </thead>
                                    <tbody id="announcement">
                                    <?php if(is_array($anlist) || $anlist instanceof \think\Collection || $anlist instanceof \think\Paginator): $i = 0; $__LIST__ = $anlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$an): $mod = ($i % 2 );++$i;?>
                                    <tr class="gradeX">
                                        <td><?php echo $an['title']; ?></td>
                                        <td><?php echo $an['author']; ?></td>
                                        <td><?php echo $an['pubdate']; ?></td>
                                        <td>
                                            <div class="tpl-table-black-operation">
                                                <a class="an_view" data-id="<?php echo $an['id']; ?>" href="javascript:;"
                                                   data-am-model="{target: '#announcewindow', closeViaDimmer: 0, width: 400, height: 225}">
                                                    <i class="am-icon-book"></i> 查看
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                    <!-- more data -->
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="am-u-sm-12 am-u-md-4">
                    <div class="widget am-cf">
                        <div class="widget-head am-cf">
                            <div class="widget-title am-fl">待办事项</div>
                            <!--<div class="widget-function am-fr">-->
                            <!--<a href="javascript:;" class="am-icon-cog"></a>-->
                            <!--</div>-->
                        </div>
                        <div class="widget-body widget-body am-fr">
                            <div class="widget-statistic-description">
                                <a href="javascript:;" class="am-badge am-badge-success am-text-default am-block">真棒，没有任何待办事项！</a>
                            </div>
                            <!--<div class="widget-statistic-description">-->
                            <!--<a class="am-badge am-badge-success am-text-default am-block">没有急需续费的订阅</a>-->
                            <!--</div>-->
                            <!--<div class="widget-statistic-description">-->
                            <!--<a class="am-badge am-badge-success am-text-default am-block">没有未支付的订单</a>-->
                            <!--</div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="am-modal am-modal-no-btn" tabindex="-1" id="announcewindow">
    <div class="am-modal-dialog">
        <div class="am-modal-hd" id="antitle" style="padding: 20px 0px 0px 20px;font-size:2em;text-align:left;"></div>
        <div style="padding-left: 20px;text-align:left;color:gray;" id="author"></div>
        <div style="padding-left: 20px;text-align: left;" class="am-modal-bd" id="ancontent">
        </div>
    </div>
</div>
</div>
<script src="/static/index-assets/js/amazeui.min.js"></script>
<script src="/static/index-assets/js/amazeui.datatables.min.js"></script>
<script src="/static/index-assets/js/dataTables.responsive.min.js"></script>
<script src="/static/index-assets/js/app.js"></script>
<script src="/static/index-assets/js/index.js"></script>
</body>

</html>