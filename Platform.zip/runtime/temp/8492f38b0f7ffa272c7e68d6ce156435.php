<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:90:"/Applications/MAMP/htdocs/cqpadmin/public/../application/admin/view/subcontrol/forsub.html";i:1536639593;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $coupon; ?> - 紫旭订阅管理平台 - 查看适用范围</title>
    <meta name="description" content="这是后台！">
    <meta name="keywords" content="index">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="icon" type="image/png" href="/static/admin-assets/i/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="/static/admin-assets/i/app-icon72x72@2x.png">
    <meta name="apple-mobile-web-app-title" content="Amaze UI"/>
</head>
<body>
<table class="am-table am-table-striped am-table-hover table-main">
    <thead>
    <tr>
        <th class="table-sid">适用的产品id(#all表示所有产品都可用)</th>
    </tr>
    </thead>
    <tbody>
    <?php if(is_array($forsub) || $forsub instanceof \think\Collection || $forsub instanceof \think\Paginator): $i = 0; $__LIST__ = $forsub;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cp): $mod = ($i % 2 );++$i;?>
    <tr>
        <td><a href="/admin/subControl/editSubIndex?sid=<?php echo $cp['sid']; ?>">#<?php echo $cp['sid']; ?></a></td>
    </tr>
    <?php endforeach; endif; else: echo "" ;endif; ?>
    </tbody>
</table>
</body>
</html>