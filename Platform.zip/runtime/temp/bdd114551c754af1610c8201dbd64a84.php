<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"/Applications/MAMP/htdocs/tp5/application/index/view/index/home.html";i:1533199906;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php echo $result['id']; ?>--<?php echo $result['data']; ?>
</body>
</html>