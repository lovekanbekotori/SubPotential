<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:88:"/Applications/MAMP/htdocs/cqpadmin/public/../application/index/view/index/subscribe.html";i:1537262549;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>产品列表 - <?php echo $title; ?> - <?php echo $subtitle; ?></title>
    <meta name="description" content="<?php echo $describe; ?>">
    <meta name="keywords" content="<?php echo $seo; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp"/>
    <link rel="icon" type="image/png" href="/static/index-assets/i/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="/static/index-assets/i/app-icon72x72@2x.png">
    <meta name="apple-mobile-web-app-title" content="Amaze UI"/>
    <link rel="stylesheet" href="/static/index-assets/css/amazeui.min.css"/>
    <link rel="stylesheet" href="/static/index-assets/css/amazeui.datatables.min.css"/>
    <link rel="stylesheet" href="/static/index-assets/css/app.css">
    <script src="/static/index-assets/js/jquery.min.js"></script>

</head>

<body data-type="widgets">
<script src="/static/index-assets/js/theme.js"></script>
<div class="am-g tpl-g">
    <!-- 头部 -->
    <header>
        <!-- logo -->
        <div class="am-fl tpl-header-logo">
            <a href="/index"><i class="am-icon-modx am-icon-md"> Hello ZSRA</i></a>
        </div>
        <!-- 右侧内容 -->
        <div class="tpl-header-fluid">
            <!-- 侧边切换 -->
            <div class="am-fl tpl-header-switch-button am-icon-list">
                    <span>

                </span>
            </div>
            <!-- 搜索 -->
            <!--<div class="am-fl tpl-header-search">-->
            <!--<form class="tpl-header-search-form" action="javascript:;">-->
            <!--<button class="tpl-header-search-btn am-icon-search"></button>-->
            <!--<input class="tpl-header-search-box" type="text" placeholder="搜索内容...">-->
            <!--</form>-->
            <!--</div>-->
            <!-- 其它功能-->
            <div class="am-fr tpl-header-navbar">
                <ul>
                    <!-- 欢迎语 -->
                    <li class="am-text-sm tpl-header-navbar-welcome">
                        <a href="javascript:;">欢迎您，<span><?php echo $me['username']; ?></span> </a>
                    </li>

                    <!-- 新邮件 -->
                    <!--<li class="am-dropdown tpl-dropdown" data-am-dropdown>-->
                    <!--<a href="javascript:;" class="am-dropdown-toggle tpl-dropdown-toggle" data-am-dropdown-toggle>-->
                    <!--<i class="am-icon-envelope"></i>-->
                    <!--<span class="am-badge am-badge-success am-round item-feed-badge">4</span>-->
                    <!--</a>-->
                    <!--&lt;!&ndash; 弹出列表 &ndash;&gt;-->
                    <!--<ul class="am-dropdown-content tpl-dropdown-content">-->
                    <!--<li class="tpl-dropdown-menu-messages">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-messages-item am-cf">-->
                    <!--<div class="menu-messages-ico">-->
                    <!--<img src="/static/index-assets/img/user04.png" alt="">-->
                    <!--</div>-->
                    <!--<div class="menu-messages-time">-->
                    <!--3小时前-->
                    <!--</div>-->
                    <!--<div class="menu-messages-content">-->
                    <!--<div class="menu-messages-content-title">-->
                    <!--<i class="am-icon-circle-o am-text-success"></i>-->
                    <!--<span>夕风色</span>-->
                    <!--</div>-->
                    <!--<div class="am-text-truncate"> Amaze UI 的诞生，依托于 GitHub 及其他技术社区上一些优秀的资源；Amaze UI 的成长，则离不开用户的支持。 </div>-->
                    <!--<div class="menu-messages-content-time">2016-09-21 下午 16:40</div>-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->

                    <!--<li class="tpl-dropdown-menu-messages">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-messages-item am-cf">-->
                    <!--<div class="menu-messages-ico">-->
                    <!--<img src="/static/index-assets/img/user02.png" alt="">-->
                    <!--</div>-->
                    <!--<div class="menu-messages-time">-->
                    <!--5天前-->
                    <!--</div>-->
                    <!--<div class="menu-messages-content">-->
                    <!--<div class="menu-messages-content-title">-->
                    <!--<i class="am-icon-circle-o am-text-warning"></i>-->
                    <!--<span>禁言小张</span>-->
                    <!--</div>-->
                    <!--<div class="am-text-truncate"> 为了能最准确的传达所描述的问题， 建议你在反馈时附上演示，方便我们理解。 </div>-->
                    <!--<div class="menu-messages-content-time">2016-09-16 上午 09:23</div>-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--<li class="tpl-dropdown-menu-messages">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-messages-item am-cf">-->
                    <!--<i class="am-icon-circle-o"></i> 进入列表…-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--</ul>-->
                    <!--</li>-->

                    <!-- 新提示 -->
                    <!--<li class="am-dropdown" data-am-dropdown>-->
                    <!--<a href="javascript:;" class="am-dropdown-toggle" data-am-dropdown-toggle>-->
                    <!--<i class="am-icon-bell"></i>-->
                    <!--<span class="am-badge am-badge-warning am-round item-feed-badge">5</span>-->
                    <!--</a>-->

                    <!--&lt;!&ndash; 弹出列表 &ndash;&gt;-->
                    <!--<ul class="am-dropdown-content tpl-dropdown-content">-->
                    <!--<li class="tpl-dropdown-menu-notifications">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-notifications-item am-cf">-->
                    <!--<div class="tpl-dropdown-menu-notifications-title">-->
                    <!--<i class="am-icon-line-chart"></i>-->
                    <!--<span> 有6笔新的销售订单</span>-->
                    <!--</div>-->
                    <!--<div class="tpl-dropdown-menu-notifications-time">-->
                    <!--12分钟前-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--<li class="tpl-dropdown-menu-notifications">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-notifications-item am-cf">-->
                    <!--<div class="tpl-dropdown-menu-notifications-title">-->
                    <!--<i class="am-icon-star"></i>-->
                    <!--<span> 有3个来自人事部的消息</span>-->
                    <!--</div>-->
                    <!--<div class="tpl-dropdown-menu-notifications-time">-->
                    <!--30分钟前-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--<li class="tpl-dropdown-menu-notifications">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-notifications-item am-cf">-->
                    <!--<div class="tpl-dropdown-menu-notifications-title">-->
                    <!--<i class="am-icon-folder-o"></i>-->
                    <!--<span> 上午开会记录存档</span>-->
                    <!--</div>-->
                    <!--<div class="tpl-dropdown-menu-notifications-time">-->
                    <!--1天前-->
                    <!--</div>-->
                    <!--</a>-->
                    <!--</li>-->


                    <!--<li class="tpl-dropdown-menu-notifications">-->
                    <!--<a href="javascript:;" class="tpl-dropdown-menu-notifications-item am-cf">-->
                    <!--<i class="am-icon-bell"></i> 进入列表…-->
                    <!--</a>-->
                    <!--</li>-->
                    <!--</ul>-->
                    <!--</li>-->

                    <!-- 退出 -->
                    <li class="am-text-sm">
                        <a href="javascript:;">
                            <span class="am-icon-sign-out"></span> 退出
                        </a>
                    </li>
                </ul>
            </div>
        </div>

    </header>
    <!-- 风格切换 -->
    <div class="tpl-skiner">
        <div class="tpl-skiner-toggle am-icon-cog">
        </div>
        <div class="tpl-skiner-content">
            <div class="tpl-skiner-content-title">
                选择主题
            </div>
            <div class="tpl-skiner-content-bar">
                <span class="skiner-color skiner-white" data-color="theme-white"></span>
                <span class="skiner-color skiner-black" data-color="theme-black"></span>
            </div>
        </div>
    </div>
    <!-- 侧边导航栏 -->
    <div class="left-sidebar">
        <!-- 用户信息 -->
        <div class="tpl-sidebar-user-panel">
            <div class="tpl-user-panel-slide-toggleable">
                <div class="tpl-user-panel-profile-picture">
                    <img src="/static/index-assets/img/user04.png" alt="">
                </div>
                <span class="user-panel-logged-in-text">
              <i class="am-icon-circle-o am-text-success tpl-user-panel-status-icon"></i>
              <?php echo $me['username']; ?>#<?php echo $me['uid']; ?>
          </span>
                <a href="javascript:;" class="tpl-user-panel-action-link"> <span class="am-icon-pencil"></span> 账号设置</a>
            </div>
        </div>


        <!-- 菜单 -->
        <ul class="sidebar-nav">
            <li class="sidebar-nav-heading">控制台 <span class="sidebar-nav-heading-info"> Console</span></li>
            <li class="sidebar-nav-link">
                <a href="/index">
                    <i class="am-icon-home sidebar-nav-link-logo"></i> 首页
                </a>
            </li>
            <li class="sidebar-nav-link">
                <a href="javascript:;" class="sidebar-nav-sub-title active">
                    <i class="am-icon-cloud sidebar-nav-link-logo"></i> 订阅管理
                    <span class="am-icon-chevron-down am-fr am-margin-right-sm sidebar-nav-sub-ico sidebar-nav-sub-ico-rotate"></span>
                </a>
                <ul class="sidebar-nav sidebar-nav-sub" style="display: block;">
                    <li class="sidebar-nav-link">
                        <a href="/index/index/mySubscribe">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 我的订阅
                        </a>
                    </li>

                    <li class="sidebar-nav-link">
                        <a href="/index/index/subscribe" class="sub-active">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 订阅列表
                        </a>
                    </li>
                </ul>
            </li>
            <li class="sidebar-nav-link">
                <a href="javascript:;" class="sidebar-nav-sub-title">
                    <i class="am-icon-google-wallet sidebar-nav-link-logo"></i> 账户管理
                    <span class="am-icon-chevron-down am-fr am-margin-right-sm sidebar-nav-sub-ico"></span>
                </a>
                <ul class="sidebar-nav sidebar-nav-sub">
                    <li class="sidebar-nav-link">
                        <a href="/index/index/account">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 我的账户
                        </a>
                    </li>
                    <li class="sidebar-nav-link">
                        <a href="/index/index/editacc">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 资料编辑
                        </a>
                    </li>
                    <li class="sidebar-nav-link">
                        <a href="javascript:;">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 购买记录
                        </a>
                    </li>
                </ul>
            </li>
            <li class="sidebar-nav-link">
                <a href="/index/index/charge">
                    <i class="am-icon-usd sidebar-nav-link-logo"></i> 账户充值
                </a>
            </li>
            <li class="sidebar-nav-link">
                <a href="javascript:;" class="sidebar-nav-sub-title">
                    <i class="am-icon-ticket sidebar-nav-link-logo"></i> 工单
                    <span class="am-icon-chevron-down am-fr am-margin-right-sm sidebar-nav-sub-ico"></span>
                </a>
                <ul class="sidebar-nav sidebar-nav-sub">
                    <li class="sidebar-nav-link">
                        <a href="javascript:;">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 我的工单
                        </a>
                    </li>
                    <li class="sidebar-nav-link">
                        <a href="javascript:;">
                            <span class="am-icon-angle-right sidebar-nav-link-logo"></span> 提交工单
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>


    <!-- 内容区域 -->
    <div class="tpl-content-wrapper">
        <div class="container-fluid am-cf">
            <div class="row">
                <div class="am-u-sm-12 am-u-md-12 am-u-lg-9">
                    <div class="page-header-heading"><span class="am-icon-home page-header-heading-icon"></span> 全部可用订阅
                        <small>ZSRA</small>
                    </div>
                    <p class="page-header-description">在下方选择您喜欢的产品进行购买！</p>
                </div>
                <!--<div class="am-u-lg-3 tpl-index-settings-button">-->
                <!--<button type="button" class="page-header-button"><span class="am-icon-paint-brush"></span> 设置</button>-->
                <!--</div>-->
            </div>
        </div>
        <div class="row-content am-cf">
            <div class="row">
                <?php if($mysubnum > 0): ?>
                <div class="am-u-sm-12 am-u-md-12 am-u-lg-12">
                    <div class="widget am-cf">
                        <div class="widget-head am-cf">
                            <div class="widget-title  am-cf">我的订阅(显示最新5条订阅)</div>
                        </div>
                        <div class="widget-body am-fr">
                            <?php if(is_array($mysub) || $mysub instanceof \think\Collection || $mysub instanceof \think\Paginator): $i = 0;$__LIST__ = is_array($mysub) ? array_slice($mysub,0,5, true) : $mysub->slice(0,5, true); if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ms): $mod = ($i % 2 );++$i;if((intval(strtotime($ms['expiretime'])/86400-time()/86400)>7)): ?>
                            <div class="am-alert am-alert-success" data-am-alert>
                                <p><i class="am-icon-info-circle"></i> #<?php echo $ms['sid']; ?> <?php echo $ms['sname']; ?>
                                    <small><?php echo $ms['starttime']; ?> 至 <?php echo $ms['expiretime']; ?></small>
                                </p>
                            </div>
                            <?php elseif((intval(strtotime($ms['expiretime'])/86400-time()/86400)>0) and (intval(strtotime($ms['expiretime'])/86400-time()/86400)<=7)): ?>
                            <div class="am-alert am-alert-warning" data-am-alert>
                                <p><i class="am-icon-info-circle"></i> #<?php echo $ms['sid']; ?> <?php echo $ms['sname']; ?>
                                    <small><?php echo $ms['starttime']; ?> 至 <?php echo $ms['expiretime']; ?></small>
                                </p>
                            </div>
                            <?php elseif((intval(strtotime($ms['expiretime'])/86400-time()/86400)<=0)): ?>
                            <div class="am-alert am-alert-danger" data-am-alert>
                                <del><i class="am-icon-warning"></i> #<?php echo $ms['sid']; ?> <?php echo $ms['sname']; ?>
                                    <small><?php echo $ms['starttime']; ?> 至 <?php echo $ms['expiretime']; ?></small>
                                </del>
                            </div>
                            <?php endif; endforeach; endif; else: echo "" ;endif; ?>
                            <!--<div class="am-alert am-alert-success" data-am-alert>-->
                            <!--<p>#68 紫旭机器人超级群管-->
                            <!--<small>2018-09-04 17:17:05 至 2018-10-05 17:17:13</small>-->
                            <!--</p>-->
                            <!--</div>-->
                            <!--<div class="am-alert am-alert-warning" data-am-alert>-->
                            <!--<p>#69 紫旭机器人超级群管-->
                            <!--<small>2018-09-04 17:17:05 至 2018-09-05 17:17:13</small>-->
                            <!--</p>-->
                            <!--</div>-->
                            <!--<div class="am-alert am-alert-danger" data-am-alert>-->
                            <!--<del>#522 紫旭机器人超级群管-->
                            <!--<small>2018-08-04 17:17:05 至 2018-08-05 17:17:13</small>-->
                            <!--</del>-->
                            <!--</div>-->
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="am-u-sm-12 am-u-md-12 am-u-lg-12">
                    <div class="widget am-cf">
                        <div class="widget-head am-cf">
                            <div class="widget-title am-cf">可用订阅列表</div>
                        </div>
                        <div class="widget-body am-fr">
                            <!--<div class="am-u-sm-12 am-u-md-6 am-u-lg-4">-->
                            <!--<div class="am-input-group am-input-group-sm tpl-form-border-form cl-p">-->
                            <!--<input type="text" class="am-form-field" placeholder="查询订阅">-->
                            <!--<span class="am-input-group-btn">-->
                            <!--<button class="am-btn  am-btn-default am-btn-success tpl-table-list-field am-icon-search"-->
                            <!--type="button"></button>-->
                            <!--</span>-->
                            <!--</div>-->
                            <!--</div>-->
                            <!--这里循环一个数组 输出商品信息-->
                            <?php if(is_array($sublist) || $sublist instanceof \think\Collection || $sublist instanceof \think\Paginator): $i = 0; $__LIST__ = $sublist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$sub): $mod = ($i % 2 );++$i;?>
                            <div class="am-u-sm-12 am-u-md-12 am-u-lg-6">
                                <div class="widget widget-primary am-cf">
                                    <div class="widget-statistic-header">
                                        <?php echo $sub['sname']; ?>
                                    </div>
                                    <div class="widget-statistic-body">
                                        <div class="widget-statistic-value">
                                            <!--这里输出最低价~最高价-->
                                            <!--解释：1判断大小价格是否相等，相等只输出一个，不相等则输出大小价格，保留2位小数-->
                                            <?php if($sub['minprice']===$sub['maxprice']): ?>￥<?php echo number_format($sub['maxprice'],2); else: ?>￥<?php echo number_format($sub['minprice'],2); ?>
                                            ~ ￥<?php echo number_format($sub['maxprice'],2); endif; ?>
                                        </div>
                                        <div class="widget-statistic-description">
                                            <!--这里输出商品描述 非数组-->
                                            <?php echo $sub['des']; ?>
                                        </div>
                                        <div class="am-fr am-cf tpl-table-list-select">
                                            <!--商品方案和价格可以用另一个方法post获取，而不在商品列表信息里不然是三维参数-->
                                            <!--这里循环数组 输出商品方案-->
                                            <br/>
                                            <button type="button" value="<?php echo $sub['sid']; ?>"
                                                    class="btn_subnow am-btn am-btn-success">立即订阅
                                            </button>
                                        </div>
                                        <span class="widget-statistic-icon am-icon-tags"></span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script src="/static/index-assets/js/amazeui.min.js"></script>
<script src="/static/index-assets/js/app.js"></script>
<script>
    $('.btn_subnow').on('click',function () {
        window.location.href = '/index/index/order?sid=' + $(this).val();
    })
</script>
</body>

</html>