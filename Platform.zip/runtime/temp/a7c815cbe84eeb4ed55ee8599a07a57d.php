<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:69:"/Applications/MAMP/htdocs/tp5/application/index/view/index/hello.html";i:1533198813;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>test</title>
</head>
<body>
<div>
    nihao,<?php echo $nice; ?>
</div>
</body>
</html>