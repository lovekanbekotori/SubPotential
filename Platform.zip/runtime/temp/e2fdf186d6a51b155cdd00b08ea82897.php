<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:97:"/Applications/MAMP/htdocs/cqpadmin Publisher/public/../application/index/view/index/register.html";i:1539528409;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo $describe; ?>">
    <meta name="keywords" content="<?php echo $seo; ?>">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="/static/assets/images/favicon.png">
    <title>创建账号 - <?php echo $title; ?> - <?php echo $subtitle; ?></title>
    <!-- Bootstrap Core CSS -->
    <link href="/static/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/assets/css/toastr.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="/static/assets/css/style.css" rel="stylesheet">
    <!-- You can change the theme colors from here -->
    <link href="/static/assets/css/colors/blue.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        body {
            background-color: #303030;
        }
    </style>
</head>

<body>
<div id="particles-js">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/>
        </svg>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <section id="wrapper">
        <div class="login-register">
            <div class="login-box card">
                <div class="card-body">
                    <form class="form-horizontal floating-labels" id="regform" action="/index/user/reg" method="post">
                        <h3 class="box-title m-b-20">创建账户</h3>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <input class="form-control" name="username" id="username" type="text" required="">
                                <span class="bar"></span>
                                <label for="username">用户名</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <input class="form-control" name="email" type="email" required="">
                                <span class="bar"></span>
                                <label>电子邮箱</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <input class="form-control" name="password" type="password" required="" minlength="6"
                                       maxlength="16">
                                <span class="bar"></span>
                                <label>密码</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <input class="form-control" data-validation-match-match="password" minlength="6"
                                       maxlength="16" type="password" required="">
                                <span class="bar"></span>
                                <label>确认密码</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <div id="captcha"></div>
                            </div>
                        </div>
                        <div class="form-group" <?php if($reg['showpolicy']===1): ?>hidden<?php endif; ?>>
                            <div class="col-md-12">

                                <input name="term" value="true" id="agreeterms" type="checkbox">
                                <label for="agreeterms"> 我已阅读和同意 <a href="#">《用户协议》</a></label>

                            </div>
                        </div>
                        <div class="form-group text-center m-t-20">
                            <div class="col-xs-12">
                                <button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light"
                                        type="submit">立即注册
                                </button>
                            </div>
                        </div>
                        <div class="form-group m-b-0">
                            <div class="col-sm-12 text-center">
                                <p>哇，我已经有账户啦!<a href="/index/index/login" class="text-info m-l-5"><b>马上登录</b></a>
                                </p>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>

    </section>
</div>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="/static/assets/plugins/jquery/jquery.min.js"></script>
<script src="/static/assets/js/toastr.min.js"></script>
<script src="/static/assets/js/jquery.form.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="/static/assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="/static/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="/static/assets/js/jquery.slimscroll.js"></script>
<!--Wave Effects -->
<script src="/static/assets/js/waves.js"></script>
<!--Menu sidebar -->
<script src="/static/assets/js/sidebarmenu.js"></script>
<!--stickey kit -->
<script src="/static/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="/static/assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<!--Custom JavaScript -->
<script src="/static/assets/js/custom.min.js"></script>
<script src="/static/assets/js/particles.min.js"></script>
<script src="/static/assets/js/index.js"></script>
<script src='/static/assets/js/gt.js'></script>
<script>
    // ! function(window, document, $) {
    //     "use strict";
    //     $("input,select,textarea").not("[type=submit]").jqBootstrapValidation(), $(".skin-square input").iCheck({
    //         checkboxClass: "icheckbox_square-green",
    //         radioClass: "iradio_square-green"
    //     }), $(".touchspin").TouchSpin(), $(".switchBootstrap").bootstrapSwitch();
    // }(window, document, jQuery);
</script>
<script>
    var regcap = <?php echo $reg['regcap']; ?>
    ;
    if (regcap === 0) {
        var regObj;
        $.ajax({
            url: "/index/index/getCaptcha",
            type: "get",
            dataType: "json",
            success: function (data) {
                data = eval('(' + data + ')');
                //请检测data的数据结构， 保证data.gt, data.challenge, data.success有值
                initGeetest({
                    // 以下配置参数来自服务端 SDK
                    gt: data.gt,
                    challenge: data.challenge,
                    offline: !data.success,
                    new_captcha: true,
                    product: 'popup'
                }, function (captchaObj) {
                    regObj = captchaObj;
                    // 这里可以调用验证实例 captchaObj 的实例方法
                    captchaObj.appendTo("#captcha"); //将验证按钮插入到宿主页面中captchaBox元素内
                    captchaObj.bindForm('#regform');
                })
            }
        })
    }
</script>
<!-- ============================================================== -->
<!-- Style switcher -->
<!-- ============================================================== -->
<script src="/static/assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>