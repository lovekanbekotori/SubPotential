<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:95:"/Applications/MAMP/htdocs/cqpadmin Publisher/public/../application/index/view/index/charge.html";i:1539450933;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo $describe; ?>">
    <meta name="keywords" content="<?php echo $seo; ?>">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="/static/assets/images/favicon.png">
    <title>充值 - <?php echo $title; ?> - <?php echo $subtitle; ?></title>
    <!-- Bootstrap Core CSS -->
    <link href="/static/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/assets/css/toastr.min.css" rel="stylesheet">
    <!-- Footable CSS -->
    <link href="/static/assets/plugins/footable/css/footable.core.css" rel="stylesheet">
    <link href="/static/assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet"/>
    <!-- Custom CSS -->
    <link href="/static/assets/css/style.css" rel="stylesheet">
    <!-- You can change the theme colors from here -->
    <link href="/static/assets/css/colors/blue.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        pagination {
            display: inline-block;
            padding-left: 0;
            margin: 20px 0;
            border-radius: 4px;
        }

        .pagination li {
            display: inline;
        }

        .pagination li a, .pagination li span {
            position: relative;
            float: left;
            padding: 6px 12px;
            margin-left: -1px;
            line-height: 1.428571429;
            text-decoration: none;
            background-color: #fff;
            border: 1px solid #ddd;
        }

        .pagination li:first-child a {
            margin-left: 0;
            border-bottom-left-radius: 4px;
            border-top-left-radius: 4px;
        }

        .pagination li:last-child a {
            border-top-right-radius: 4px;
            border-bottom-right-radius: 4px;
        }

        .pagination li a:hover, .pagination li a:focus {
            background-color: #eee;
        }

        .pagination .active span, .pagination .active span:hover, .pagination .active span:focus {
            z-index: 2;
            color: #fff;
            cursor: default;
            background-color: #428bca;
            border-color: #428bca;
        }

        .pagination .disabled span, .pagination .disabled span:hover, .pagination .disabled span:focus {
            color: #999;
            cursor: not-allowed;
            background-color: #fff;
            border-color: #ddd;
        }

        .pagination-lg li a {
            padding: 10px 16px;
            font-size: 18px;
        }

        .pagination-sm li a, .pagination-sm li span {
            padding: 5px 10px;
            font-size: 12px;
        }
    </style>
</head>

<body class="fix-header card-no-border logo-center">
<!-- ============================================================== -->
<!-- Preloader - style you can find in spinners.css -->
<!-- ============================================================== -->
<div class="preloader">
    <svg class="circular" viewBox="25 25 50 50">
        <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/>
    </svg>
</div>
<!-- ============================================================== -->
<!-- Main wrapper - style you can find in pages.scss -->
<!-- ============================================================== -->
<div id="main-wrapper">
    <!-- ============================================================== -->
    <!-- Topbar header - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <header class="topbar">
        <nav class="navbar top-navbar navbar-expand-md navbar-light">
            <!-- ============================================================== -->
            <!-- Logo -->
            <!-- ============================================================== -->
            <div class="navbar-header">
                <a class="navbar-brand" href="/index">
                    <!-- Logo icon -->
                    <b>
                        <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                        <!-- Dark Logo icon -->
                        <!--<img src="/static/assets/images/logo-icon.png" alt="homepage" class="dark-logo" />-->
                        <!-- Light Logo icon -->
                        <!--<img src="/static/assets/images/logo-light-icon.png" alt="homepage" class="light-logo" />-->
                        <i class="fa fa-modx light-logo"> <span>紫旭产品订阅平台</span></i>
                    </b>
                    <!--End Logo icon -->
                    <!-- Logo text -->
                </a>
            </div>
            <!-- ============================================================== -->
            <!-- End Logo -->
            <!-- ============================================================== -->
            <div class="navbar-collapse">
                <!-- ============================================================== -->
                <!-- toggle and nav items -->
                <!-- ============================================================== -->
                <ul class="navbar-nav mr-auto mt-md-0">
                    <!-- This is  -->
                    <li class="nav-item"><a class="nav-link nav-toggler hidden-md-up text-muted waves-effect waves-dark"
                                            href="javascript:void(0)"><i class="mdi mdi-menu"></i></a></li>
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                </ul>
                <!-- ============================================================== -->
                <!-- User profile and search -->
                <!-- ============================================================== -->
                <ul class="navbar-nav my-lg-0">
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Messages -->
                    <!-- ============================================================== -->

                    <!-- ============================================================== -->
                    <!-- End Messages -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Profile -->
                    <!-- ============================================================== -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href=""
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img
                                src="<?php echo $avatar; ?>" alt="user" class="profile-pic"/></a>
                        <div class="dropdown-menu dropdown-menu-right scale-up">
                            <ul class="dropdown-user">
                                <li>
                                    <div class="dw-user-box">
                                        <div class="u-img"><img src="<?php echo $avatar; ?>" alt="user">
                                        </div>
                                        <div class="u-text" style="width: 146px;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                            <h4><?php echo $me['username']; ?></h4>
                                            <p class="text-muted"><?php echo $me['email']; ?></p>
                                            <div><h6><font color="<?php echo $group['groupcolor']; ?>"><?php echo $group['groupname']; ?></font></h6>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li role="separator" class="divider"></li>
                                <li><a href="/index/index/account"><i class="ti-user"></i> 个人中心</a></li>


                                <li role="separator" class="divider"></li>
                                <li><a href="/index/index/account"><i class="ti-settings"></i> 设置</a></li>
                                <li role="separator" class="divider"></li>
                                <li><a href="/index/user/logout"><i class="fa fa-power-off"></i> 退出登录</a></li>
                            </ul>
                        </div>
                    </li>
                    <!-- ============================================================== -->
                    <!-- Language -->
                    <!-- ============================================================== -->
                    <li class="nav-item dropdown">
                        <a class="nav-link waves-effect waves-dark" href="javascript:;"><i
                                class="flag-icon flag-icon-cn"></i></a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <!-- ============================================================== -->
    <!-- End Topbar header -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <aside class="left-sidebar">
        <!-- Sidebar scroll-->
        <div class="scroll-sidebar">
            <!-- Sidebar navigation-->
            <nav class="sidebar-nav">
                <ul id="sidebarnav">
                    <li>
                        <a class="has-arrow" href="javascript:;" aria-expanded="false"><i
                                class="mdi mdi-gauge"></i><span
                                class="hide-menu">控制台</span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li><a href="/index/">主控制台</a></li>
                        </ul>
                    </li>
                    <li>
                        <a class="has-arrow" href="javascript:;" aria-expanded="false"><i
                                class="mdi mdi-widgets"></i><span
                                class="hide-menu">订阅管理</span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li><a href="/index/index/mySubscription">我的订阅</a></li>
                            <li><a href="/index/index/buyRecord">购买记录</a></li>
                        </ul>
                    </li>
                    <li class="active">
                        <a class="has-arrow" href="javascript:;" aria-expanded="false"><i
                                class="mdi mdi-shopping"></i><span
                                class="hide-menu">商店</span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li><a href="/index/index/subscriptions">全部商品</a></li>
                            <li class="active"><a href="/index/index/charge">充值</a></li>

                        </ul>
                    </li>
                    <li>
                        <a class="has-arrow " href="#" aria-expanded="false"><i class="mdi mdi-ticket-account"></i><span
                                class="hide-menu">工单</span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li><a href="/index/index/ticket">工单列表</a></li>
                            <li><a href="/index/index/newTicket">创建工单</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
            <!-- End Sidebar navigation -->
        </div>
        <!-- End Sidebar scroll-->
    </aside>
    <!-- ============================================================== -->
    <!-- End Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Page wrapper  -->
    <!-- ============================================================== -->
    <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 col-8 align-self-center">
                    <h3 class="text-themecolor m-b-0 m-t-0">充值</h3>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">商店</a></li>
                        <li class="breadcrumb-item active">充值</li>
                    </ol>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Start Page Content -->
            <!-- ============================================================== -->
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-warning">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                        <h3 class="text-warning"><i class="fa fa-exclamation-triangle"></i> 请注意</h3>
                        欢迎您进行充值功能的测试，测试期间最低充值金额为0.01元。<br/>
                        测试期间，所有充值过10元以上的用户，测试期结束后将获得等额的金额奖励！（如：测试期间充值了2笔，每笔12元，测试结束后将获得24元奖励，总计48元，多充多送）<br/>
                    </div>
                    <!-- Column -->
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">请您注意！</h4>
                            <h6 class="card-subtitle">充值完毕后请刷新网页查看余额，正常情况支付成功后1分钟内到账。</h6>
                            <h4>如果没到账请在24小时内<a href="/index/index/newTicket">提交工单</a>，过期将无法处理！</h4>
                            <h6>没到账的，超过24小时一律没法处理！记住！一定要在24小时创建工单！</h6>
                            <h4>管理员邮箱：administrator@zixutech.cn</h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <!-- Column -->
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">账户充值</h4>
                            <h6 class="card-subtitle">当前余额：<span class="label label-light-primary"><?php echo number_format($me['cash'],2); ?></span>
                                元</h6>
                            <br/>
                            <div id="chargemodel" class="modal fade" tabindex="-1" role="dialog"
                                 aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title" id="ctitle"></h4>
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                ×
                                            </button>
                                        </div>
                                        <div class="modal-body text-center">
                                            <h1 id="csubtitle"></h1>
                                            <div id="qrcode" style="display: inline-block;"></div>
                                            <div id="success" hidden><img src="/static/assets/images/success.png"></div>
                                            <p id="ccontent"></p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-info waves-effect"
                                                    data-dismiss="modal">关闭
                                            </button>
                                        </div>
                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
                            <form id="normalPayForm" action="/index/index/normalCharge" method="post"
                                  class="form-horizontal floating-labels">
                                <div class="b-r form-group">
                                    <div>请选择支付方式</div>
                                    <?php if(is_array($method) || $method instanceof \think\Collection || $method instanceof \think\Paginator): $i = 0; $__LIST__ = $method;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$m): $mod = ($i % 2 );++$i;if($m['secureid']!="0"): ?>
                                    <input value="<?php echo $m['id']; ?>" type="radio" class="method with-gap radio-col-purple"
                                           id="method_<?php echo $m['id']; ?>"
                                           name="square-radio">
                                    <label for="method_<?php echo $m['id']; ?>">
                                        <?php if($m['mname']!="支付宝" && $m['mname']!="微信支付" && $m['mname']!="QQ钱包"): ?>
                                        扫码支付
                                        <?php else: ?>
                                        <?php echo $m['mname']; endif; ?>
                                    </label>
                                    <?php endif; ?>
                                    <!--<button type="button" class="btn btn-rounded btn-outline-info waves-effect">-->
                                    <!--<?php if($m['mname']!="支付宝" && $m['mname']!="微信支付" && $m['mname']!="QQ钱包"): ?>-->
                                    <!--扫码支付-->
                                    <!--<?php else: ?>-->
                                    <!--<?php echo $m['mname']; ?>-->
                                    <!--<?php endif; ?>-->
                                    <!--</button>-->
                                    <!--<?php endforeach; endif; else: echo "" ;endif; ?>-->
                                </div>
                                <br/>
                                <div class="form-group">
                                    <input id="chargecount" name="count" type="number" value="0.01" min="0.01"
                                           class="form-control form-control-line">
                                    <span class="bar"></span>
                                    <label>充值金额</label>
                                </div>
                                <div class="form-group">
                                    <button type="button" id="normalcharge"
                                            class="btn btn-success btn-rounded waves-effect"><i class="fa fa-check"></i>
                                        充值
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <!-- Column -->
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">序列号充值</h4>
                            <h6 class="card-subtitle">每个序列号仅能使用1次。</h6>
                            <br/>
                            <form id="cardPayForm" action="/index/index/cardCharge" method="post"
                                  class="form-horizontal floating-labels">
                                <div class="form-group">
                                    <input name="count" id="card" type="text" class="form-control form-control-line">
                                    <span class="bar"></span>
                                    <label>输入序列号</label>
                                    <small class="font-13 text-muted">序列号是一个20位的字母与数字组合</small>
                                </div>
                                <div class="form-group">
                                    <button type="button" id="cardcharge"
                                            class="btn btn-success btn-rounded waves-effect"><i class="fa fa-check"></i>
                                        充值
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">充值记录</h4>
                            <div class="table-responsive">
                                <table id="demo-foo-accordion" class="table table-hover">
                                    <thead>
                                    <tr>
                                        <th>订单号</th>
                                        <th>支付方式</th>
                                        <th>类型</th>
                                        <th>金额</th>
                                        <th>状态</th>
                                        <th>时间</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(is_array($record) || $record instanceof \think\Collection || $record instanceof \think\Paginator): $i = 0; $__LIST__ = $record;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$r): $mod = ($i % 2 );++$i;?>
                                    <tr>
                                        <td><?php echo $r['orderid']; ?></td>
                                        <td><?php echo $r['method']; ?></td>
                                        <td>
                                            <?php if($r['type']=="cash"): ?>
                                            账户充值
                                            <?php endif; ?>
                                        </td>
                                        <td><i class="fa fa-cny"></i> <?php echo number_format($r['count'],2); ?></td>
                                        <td>
                                            <?php if($r['status']=="0"): ?>
                                            未支付
                                            <?php else: ?>
                                            已支付
                                            <?php endif; ?>
                                        </td>
                                        <td><i class="fa fa-clock-o"></i> <?php echo $r['date']; ?></td>
                                    </tr>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                    </tbody>
                                </table>
                                <div id="pages" class="float-right">
                                    <?php if($record->currentPage()>1): ?>
                                    <button id="pre" type="button" class="btn btn-secondary" data-page="/index/index/charge?page=<?php echo $record->currentPage()-1; ?>">上一页</button>
                                    <?php endif; ?>
                                    <div class="btn-group" role="group">
                                        <?php $__FOR_START_1728458850__=1;$__FOR_END_1728458850__=$record->lastPage()+1;for($page=$__FOR_START_1728458850__;$page < $__FOR_END_1728458850__;$page+=1){ ?>
                                        <button type="button" class="pages btn <?php if($page==$record->currentPage()): ?>btn-info<?php else: ?>btn-secondary<?php endif; ?>" data-page="/index/index/charge?page=<?php echo $page; ?>"><?php echo $page; ?></button>
                                        <?php } ?>
                                    </div>
                                    <?php if($record->currentPage()<$record->lastPage()): ?>
                                    <button id="af" type="button" class="btn btn-secondary" data-page="/index/index/charge?page=<?php echo $record->currentPage()+1; ?>">下一页</button>
                                    <?php endif; ?>
                                </div>
                                <!--这里写分页代码-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End PAge Content -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Right sidebar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Container fluid  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer --><br/>
        <!-- ============================================================== -->
        <footer class="footer">
            © 2018 紫旭网络
            <br>
            <a href="javascript:;">备案号</a>
        </footer>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Page wrapper  -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="/static/assets/plugins/jquery/jquery.min.js"></script>
<script src="/static/assets/js/toastr.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="/static/assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="/static/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="/static/assets/js/jquery.slimscroll.js"></script>
<!--Wave Effects -->
<script src="/static/assets/js/waves.js"></script>
<!--Menu sidebar -->
<script src="/static/assets/js/sidebarmenu.js"></script>
<!--stickey kit -->
<script src="/static/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<!--Custom JavaScript -->
<script src="/static/assets/js/custom.min.js"></script>
<script src="/static/assets/js/qrcode.min.js"></script>
<script src="/static/assets/js/charge.js"></script>
<!-- Footable -->
<script src="/static/assets/plugins/footable/js/footable.all.min.js"></script>
<script src="/static/assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<!--FooTable init-->
<script src="/static/assets/js/footable-init.js"></script>
<!-- ============================================================== -->
<!-- Style switcher -->
<!-- ============================================================== -->
<!--<script src="/static/assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>-->
</body>

</html>
