<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:95:"/Applications/MAMP/htdocs/cqpadmin Publisher/public/../application/index/view/index/login1.html";i:1539527906;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo $describe; ?>">
    <meta name="keywords" content="<?php echo $seo; ?>">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="/static/assets/images/favicon.png">
    <title>登录 - <?php echo $title; ?> - <?php echo $subtitle; ?></title>
    <!-- Bootstrap Core CSS -->
    <link href="/static/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/assets/css/toastr.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="/static/assets/css/style.css" rel="stylesheet">
    <!-- You can change the theme colors from here -->
    <link href="/static/assets/css/colors/blue.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        body{
            background-color: #303030;
        }
    </style>
</head>

<body id="particles-js">
<!-- ============================================================== -->
<!-- Preloader - style you can find in spinners.css -->
<!-- ============================================================== -->
<div class="preloader">
    <svg class="circular" viewBox="25 25 50 50">
        <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/>
    </svg>
</div>
<!-- ============================================================== -->
<!-- Main wrapper - style you can find in pages.scss -->
<!-- ============================================================== -->
<section id="wrapper">
    <div class="login-register">
        <div class="login-box card">
            <div class="card-body">
                <form class="form-horizontal floating-labels" id="loginform" action="/index/user/login" method="post">
                    <h3 class="box-title m-b-20">登录</h3>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control" name="email" type="email" required="">
                            <span class="bar"></span>
                            <label>邮箱地址</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control" name="password" type="password" required="">
                            <span class="bar"></span>
                            <label>密码</label></div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <div id="captcha"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="checkbox checkbox-primary pull-left p-t-0">
                                <input id="checkbox-remember" name="remember" value="true" type="checkbox">
                                <label for="checkbox-remember"> 7天内记住我 </label>
                            </div>
                            <a href="javascript:void(0)" id="to-recover" class="text-dark pull-right"><i
                                    class="fa fa-lock m-r-5"></i> 忘记密码？</a></div>
                    </div>
                    <div class="row">
                    </div>
                    <div class="form-group text-center m-t-20">
                        <div class="col-xs-12">
                            <button id="login"
                                    class="btn btn-info btn-md btn-block text-uppercase waves-effect waves-light"
                                    type="submit">立即登录
                            </button>
                        </div>
                    </div>
                    <div class="form-group m-b-0">
                        <div class="col-sm-12 text-center">
                            <p>什么！你还没有账户？ <a href="/index/index/register" class="text-info m-l-5"><b>马上来一个</b></a></p>
                        </div>
                    </div>
                </form>
                <form class="form-horizontal floating-labels" id="recoverform" action="/index/user/recovery" method="post">
                    <div class="form-group ">
                        <div class="col-xs-12">
                            <h3>找回密码</h3>
                            <p class="text-muted">请输入您的注册邮箱，然后遵循邮件内的步骤来找回! </p>
                        </div>
                    </div>
                    <div class="form-group ">
                        <div class="col-xs-12">
                            <input name="email" class="form-control" type="email" required="">
                            <span class="bar"></span>
                            <label>注册邮箱</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <div id="captcha2"></div>
                        </div>
                    </div>
                    <div class="form-group text-center m-t-20">
                        <div class="col-xs-12">
                            <button id="recover" class="btn btn-primary btn-lg btn-block text-uppercase waves-effect waves-light"
                                    type="submit">找回
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

</section>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="/static/assets/plugins/jquery/jquery.min.js"></script>
<script src="/static/assets/js/toastr.min.js"></script>
<script src="/static/assets/js/jquery.form.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="/static/assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="/static/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="/static/assets/js/jquery.slimscroll.js"></script>
<!--Wave Effects -->
<script src="/static/assets/js/waves.js"></script>
<!--Menu sidebar -->
<script src="/static/assets/js/sidebarmenu.js"></script>
<!--stickey kit -->
<script src="/static/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="/static/assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<!--Custom JavaScript -->
<script src="/static/assets/js/custom.min.js"></script>
<script src="/static/assets/js/particles.min.js"></script>
<script src="/static/assets/js/index.js"></script>
<script src="/static/assets/js/gt.js"></script>
<script>
    var logincap = <?php echo $login['logincap']; ?>;

    if (logincap === 0) {
        var logincapObj;
        $.ajax({
            url: "/index/index/getCaptcha",
            type: "get",
            dataType: "json",
            success: function (data) {
                data = eval('(' + data + ')');
                //请检测data的数据结构， 保证data.gt, data.challenge, data.success有值
                initGeetest({
                    // 以下配置参数来自服务端 SDK
                    gt: data.gt,
                    challenge: data.challenge,
                    offline: !data.success,
                    new_captcha: true,
                    product: 'popup'
                }, function (captchaObj) {
                    logincapObj = captchaObj;
                    // 这里可以调用验证实例 captchaObj 的实例方法
                    captchaObj.appendTo("#captcha"); //将验证按钮插入到宿主页面中captchaBox元素内
                    captchaObj.bindForm('#loginform');
                })
            }
        })
    }
</script>
<!-- ============================================================== -->
<!-- Style switcher -->
<!-- ============================================================== -->
<script src="/static/assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
</body>

</html>